
import streamlit as st
import pandas as pd
from preprocessing import load_data
from threshold_methods import rolling_threshold, garch_evt_threshold, isolation_forest_threshold, one_class_svm_threshold, regime_change_threshold
from cross_currency_logic import assign_manual_group

st.set_page_config(layout="wide")
st.title("FX Dynamic Thresholding Dashboard")

uploaded_file = st.file_uploader("Upload Volatility Data CSV", type=["csv"])
if uploaded_file:
    df = load_data(uploaded_file)
    currencies = df['Currency'].unique().tolist()
    currency = st.selectbox("Select Currency", currencies)
    percentile = st.slider("Select Percentile for Thresholding", 90, 99, 95) / 100

    df_filtered = df[df['Currency'] == currency].copy()

    st.subheader("Manual Group Assignment")
    avg_vol = df_filtered['VolatilityOHLC'].mean()
    group = assign_manual_group(avg_vol)
    st.write(f"Assigned Manual Group: **{group}**")

    st.subheader("Dynamic Thresholds")
    st.write(f"Rolling Window Threshold ({percentile*100}%):", rolling_threshold(df_filtered, window=60, percentile=percentile).dropna().iloc[-1])
    st.write(f"GARCH-EVT Threshold ({percentile*100}%):", garch_evt_threshold(df_filtered, percentile=percentile))
    st.write(f"Isolation Forest Threshold:", isolation_forest_threshold(df_filtered))
    st.write(f"One-Class SVM Threshold:", one_class_svm_threshold(df_filtered))
    st.write(f"Regime Change Detection Threshold:", regime_change_threshold(df_filtered).dropna().iloc[-1])
