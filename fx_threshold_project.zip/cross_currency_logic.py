
def assign_manual_group(vol):
    if vol <= 0.07:
        return 'Low'
    elif vol <= 0.5:
        return 'Medium'
    elif vol <= 0.6:
        return 'High'
    else:
        return 'Very High'

def cross_currency_threshold(group1, group2):
    groups = {'Low': 1, 'Medium': 2, 'High': 3, 'Very High': 4}
    return max(groups[group1], groups[group2])
