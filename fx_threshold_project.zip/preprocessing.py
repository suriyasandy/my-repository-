
import pandas as pd
import numpy as np

def load_data(file_path):
    df = pd.read_csv(file_path)
    df['Date'] = pd.to_datetime(df['Date'])
    df['VolatilityOHLC'] = df['VolatilityOHLC'] * np.sqrt(252)  # Annualize volatility
    return df
