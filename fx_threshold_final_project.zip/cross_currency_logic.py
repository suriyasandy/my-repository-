# Final cross-currency manual group logic
