
import plotly.express as px

def plot_thresholds(df, thresholds_dict):
    fig = px.line(df, x='Date', y='VolatilityOHLC', title='Volatility and Thresholds')
    for method, threshold in thresholds_dict.items():
        fig.add_scatter(x=df['Date'], y=[threshold]*len(df), mode='lines', name=method)
    return fig
