
def calculate_synthetic_cross_volatility(base_vol, quote_vol):
    return (base_vol + quote_vol) / 2
