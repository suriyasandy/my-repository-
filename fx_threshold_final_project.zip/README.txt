FX Two-Sided Threshold Monitoring Project

Instructions:
1. pip install streamlit pandas numpy scikit-learn arch scipy plotly openpyxl
2. Run: streamlit run app.py
