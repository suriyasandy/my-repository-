
import numpy as np
import pandas as pd
from arch import arch_model
from scipy.stats import genpareto
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM

def rolling_threshold(df, window=60, percentile=0.95):
    return df['VolatilityOHLC'].rolling(window=window).quantile(percentile)

def garch_evt_threshold(df, percentile=0.95):
    returns = df['VolatilityOHLC'].pct_change().dropna() * 100
    am = arch_model(returns, vol='Garch', p=1, q=1)
    res = am.fit(disp='off')
    conditional_vol = res.conditional_volatility
    residuals = returns / conditional_vol
    params = genpareto.fit(residuals[residuals > residuals.quantile(percentile)])
    threshold = genpareto.ppf(percentile, *params)
    return threshold * conditional_vol.mean()

def isolation_forest_threshold(df):
    best_model = IsolationForest(contamination=0.03, n_estimators=100, random_state=42)
    df['anomaly'] = best_model.fit_predict(df[['VolatilityOHLC']])
    return df['VolatilityOHLC'][df['anomaly'] == -1].min()

def one_class_svm_threshold(df):
    model = OneClassSVM(nu=0.05, kernel="rbf", gamma='scale')
    model.fit(df[['VolatilityOHLC']])
    preds = model.predict(df[['VolatilityOHLC']])
    return df['VolatilityOHLC'][preds == -1].min()

def regime_change_threshold(df, window=30):
    rolling_mean = df['VolatilityOHLC'].rolling(window=window).mean()
    rolling_std = df['VolatilityOHLC'].rolling(window=window).std()
    threshold = rolling_mean + 2 * rolling_std
    return threshold
