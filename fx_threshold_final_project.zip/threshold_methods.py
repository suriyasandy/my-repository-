# Final thresholding models (Rolling, GARCH-EVT, Isolation Forest, SVM, Regime Detection)
