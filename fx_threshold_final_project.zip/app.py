
import streamlit as st
import pandas as pd
from preprocessing import load_data
from threshold_methods import *
from cross_currency_logic import assign_manual_group
from visualization import plot_thresholds

st.set_page_config(layout="wide")
st.title("FX Dynamic Thresholding Dashboard")

uploaded_file = st.file_uploader("Upload Volatility Data CSV", type=["csv"])
if uploaded_file:
    df = load_data(uploaded_file)
    st.success("Missing values interpolated where needed.")

    currencies = df['Currency'].unique().tolist()
    currency = st.selectbox("Select Currency", currencies)
    percentile = st.slider("Select Percentile for Thresholding", 90, 99, 95) / 100

    df_filtered = df[df['Currency'] == currency].copy()

    st.subheader("Manual Group Assignment")
    avg_vol = df_filtered['VolatilityOHLC'].mean()
    group = assign_manual_group(avg_vol)
    st.write(f"Assigned Manual Group: **{group}**")

    st.subheader("Dynamic Thresholds")
    thresholds = {}
    thresholds['Rolling'] = rolling_threshold(df_filtered, window=60, percentile=percentile).dropna().iloc[-1]
    thresholds['GARCH-EVT'] = garch_evt_threshold(df_filtered, percentile=percentile)
    thresholds['Isolation Forest'] = isolation_forest_threshold(df_filtered)
    thresholds['One-Class SVM'] = one_class_svm_threshold(df_filtered)
    thresholds['Regime Detection'] = regime_change_threshold(df_filtered).dropna().iloc[-1]

    st.dataframe(pd.DataFrame(thresholds.items(), columns=["Method", "Threshold Value"]))

    fig = plot_thresholds(df_filtered, thresholds)
    st.plotly_chart(fig, use_container_width=True)

    download_df = pd.DataFrame(thresholds.items(), columns=["Method", "Threshold Value"])
    st.download_button("Download Thresholds as CSV", data=download_df.to_csv(index=False), file_name="thresholds_summary.csv")
